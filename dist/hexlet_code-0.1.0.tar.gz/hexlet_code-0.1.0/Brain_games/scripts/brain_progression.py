#!/usr/bin/env python3
from Brain_games.Games.progression import do_game_progression


def main():
    print('Welcome to the Brain Games!')
    do_game_progression()


if __name__ == '__main__':
    main()
