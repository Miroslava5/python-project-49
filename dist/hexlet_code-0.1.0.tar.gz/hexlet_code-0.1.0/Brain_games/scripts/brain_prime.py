#!/usr/bin/env python3
from Brain_games.Games.prime import do_game_prime


def main():
    print('Welcome to the Brain Games!')
    do_game_prime()


if __name__ == '__main__':
    main()
