### Hexlet tests and linter status:
[![Actions Status](https://github.com/Miroslava5/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Miroslava5/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/4a6eb252d1c2848af8bb/maintainability)](https://codeclimate.com/github/Miroslava5/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/4a6eb252d1c2848af8bb/test_coverage)](https://codeclimate.com/github/Miroslava5/python-project-49/test_coverage)

[![Asciinema]](https://asciinema.org/a/4dfgOsp0pZQj7PpzCXeFulXG5)
