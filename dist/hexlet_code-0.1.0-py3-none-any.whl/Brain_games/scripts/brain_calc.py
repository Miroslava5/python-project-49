#!/usr/bin/env python3
from Brain_games.Games.calc import do_game_calc


def main():
    print('Welcome to the Brain Games!')
    do_game_calc()


if __name__ == '__main__':
    main()
