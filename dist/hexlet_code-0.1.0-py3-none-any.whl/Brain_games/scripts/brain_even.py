#!/usr/bin/env python3
from Brain_games.Games.even import do_game_even


def main():
    print('Welcome to the Brain Games!')
    do_game_even()


if __name__ == '__main__':
    main()
